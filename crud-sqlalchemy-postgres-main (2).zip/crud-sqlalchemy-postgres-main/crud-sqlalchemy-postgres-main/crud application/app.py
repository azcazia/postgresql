from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import text

app = Flask(__name__)
app.secret_key = "your_secret_key"

# Configure PostgreSQL database
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:123abc@localhost:5432/students'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Define the Student model
class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    fname = db.Column(db.String(100), nullable=False)
    lname = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)

# Create the database and tables
with app.app_context():
    db.create_all()

@app.route('/')
def index():
    try:
        # Get sorting parameter from query string, default to 'fname'
        sort_by = request.args.get('sort', 'fname')
        if sort_by not in ['id', 'fname', 'lname']:
            sort_by = 'fname'

        ## Use SQLAlchemy's text() function for raw SQL query
        # query = text(f"SELECT * FROM student ORDER BY {sort_by}")
        # result = db.session.execute(query)
        # list_users = result.fetchall()
        # Use ORM to query the database and sort the results
        list_users = Student.query.order_by(getattr(Student, sort_by)).all()

        return render_template('index.html', list_users=list_users, sort_by=sort_by)
    except Exception as e:
        print(f"Error in index route: {e}")
        return "Internal Server Error", 500

@app.route('/add_student', methods=['GET','POST'])
def add_student():
    try:
        fname = request.form.get('fname')
        lname = request.form.get('lname')
        email = request.form.get('email')

        print(f"Received data - First Name: {fname}, Last Name: {lname}, Email: {email}")

        # Validate if email already exists
        existing_student = Student.query.filter_by(email=email).first()
        if existing_student:
            flash('Email already exists!', 'danger')
            return redirect(url_for('add_student'))

        # Add new student to the database
        new_student = Student(fname=fname, lname=lname, email=email)
        db.session.add(new_student)
        db.session.commit()
        flash('Student added successfully!', 'success')
        return redirect(url_for('index'))
    except Exception as e:
        print(f"Error in add_student route: {e}")
        return "Internal Server Error", 500

@app.route('/edit_student/<int:student_id>', methods=['GET', 'POST'])
def edit_student(student_id):
    student = Student.query.get_or_404(student_id)
    if request.method == 'POST':
        student.fname = request.form['fname']
        student.lname = request.form['lname']
        student.email = request.form['email']
        db.session.commit()
        flash('Student updated successfully!', 'success')
        return redirect(url_for('index'))

    return render_template('edit_student.html', student=student)

@app.route('/delete_student/<int:student_id>')
def delete_student(student_id):
    student = Student.query.get_or_404(student_id)
    db.session.delete(student)
    db.session.commit()
    flash('Student deleted successfully!', 'success')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)


#////////////////////////////////////////////////
# from flask import Flask, render_template, request, redirect, url_for, flash
# from flask_sqlalchemy import SQLAlchemy

# app = Flask(__name__)
# app.secret_key = "your_secret_key"

# # def favicon():
# #     return '', 204

# # Configure PostgreSQL database
# app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:123abc@localhost:5432/students'
# app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
# db = SQLAlchemy(app)

# # Define the Student model
# class Student(db.Model):
#     id = db.Column(db.Integer, primary_key=True)
#     fname = db.Column(db.String(100), nullable=False)
#     lname = db.Column(db.String(100), nullable=False)
#     email = db.Column(db.String(100), unique=True, nullable=False)

# # Define the Course model
# class Course(db.Model):
#     id = db.Column(db.Integer, primary_key=True)
#     course_name = db.Column(db.String(100), unique=True, nullable=False)

# # Define the ChosenCourse model with foreign keys to Student and Course
# class ChosenCourse(db.Model):
#     id = db.Column(db.Integer, primary_key=True)
#     student_id = db.Column(db.Integer, db.ForeignKey('student.id'), nullable=False)
#     course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=False)
#     student = db.relationship('Student', backref=db.backref('chosen_courses', lazy=True))
#     course = db.relationship('Course', backref=db.backref('chosen_courses', lazy=True))

# # Create the database and tables
# with app.app_context():
#     db.drop_all()
#     db.create_all()

# @app.route('/')
# def index():
#     try:
#         sort_by = request.args.get('sort', 'fname')
#         if sort_by not in ['id', 'fname', 'lname']:
#             sort_by = 'fname'

#         students = Student.query.order_by(sort_by).all()
#         return render_template('index.html', students=students, sort_by=sort_by)
#     except Exception as e:
#         print(f"Error in index route: {e}")
#         return "Internal Server Error", 500

# @app.route('/add_student', methods=['POST'])
# def add_student():
#     fname = request.form['fname']
#     lname = request.form['lname']
#     email = request.form['email']

#     existing_student = Student.query.filter_by(email=email).first()
#     if existing_student:
#         flash('Email already exists!', 'danger')
#         return redirect(url_for('index'))

#     new_student = Student(fname=fname, lname=lname, email=email)
#     db.session.add(new_student)
#     db.session.commit()
#     flash('Student added successfully!', 'success')
#     return redirect(url_for('index'))

# @app.route('/edit_student/<int:student_id>', methods=['GET', 'POST'])
# def edit_student(student_id):
#     student = Student.query.get_or_404(student_id)
#     if request.method == 'POST':
#         student.fname = request.form['fname']
#         student.lname = request.form['lname']
#         student.email = request.form['email']
#         db.session.commit()
#         flash('Student updated successfully!', 'success')
#         return redirect(url_for('index'))

#     return render_template('edit_student.html', student=student)

# @app.route('/delete_student/<int:student_id>')
# def delete_student(student_id):
#     student = Student.query.get_or_404(student_id)
#     db.session.delete(student)
#     db.session.commit()
#     flash('Student deleted successfully!', 'success')
#     return redirect(url_for('index'))

# @app.route('/add_course', methods=['GET', 'POST'])
# def add_new_course():
#     if request.method == 'POST':
#         course_name = request.form['course_name']
#         existing_course = Course.query.filter_by(course_name=course_name).first()
#         if existing_course:
#             flash('Course already exists!', 'danger')
#         else:
#             new_course = Course(course_name=course_name)
#             db.session.add(new_course)
#             db.session.commit()
#             flash('Course added successfully!', 'success')
#         return redirect(url_for('index'))

#     return render_template('add_course.html')

# @app.route('/student/<int:student_id>/courses')
# def student_courses(student_id):
#     student = Student.query.get_or_404(student_id)
#     chosen_courses = ChosenCourse.query.filter_by(student_id=student_id).all()
#     return render_template('student_courses.html', student=student, courses=chosen_courses)

# @app.route('/student/<int:student_id>/add_course', methods=['GET', 'POST'])
# def add_course(student_id):
#     student = Student.query.get_or_404(student_id)
#     courses = Course.query.all()
#     if request.method == 'POST':
#         course_id = request.form['course_id']
#         existing_choice = ChosenCourse.query.filter_by(student_id=student_id, course_id=course_id).first()
#         if existing_choice:
#             flash('Course already chosen by the student!', 'danger')
#         else:
#             new_chosen_course = ChosenCourse(student_id=student_id, course_id=course_id)
#             db.session.add(new_chosen_course)
#             db.session.commit()
#             flash(f'Course added for {student.fname} {student.lname}!', 'success')
#         return redirect(url_for('student_courses', student_id=student_id))

#     return render_template('choose_course.html', student=student, courses=courses)

# @app.route('/delete_course/<int:course_id>/<int:student_id>')
# def delete_course(course_id, student_id):
#     chosen_course = ChosenCourse.query.filter_by(course_id=course_id, student_id=student_id).first_or_404()
#     db.session.delete(chosen_course)
#     db.session.commit()
#     flash('Course deleted successfully!', 'success')
#     return redirect(url_for('student_courses', student_id=student_id))

# @app.route('/student/<int:student_id>/course/<int:course_id>/edit', methods=['GET', 'POST'])
# def edit_course(student_id, course_id):
#     course = Course.query.get_or_404(course_id)
#     student = Student.query.get_or_404(student_id)
    
#     if request.method == 'POST':
#         course.course_name = request.form['course_name']
#         db.session.commit()
#         flash('Course updated successfully!', 'success')
#         return redirect(url_for('student_courses', student_id=student.id))
    
#     return render_template('edit_course.html', student=student, course=course)

# @app.route('/student/<int:student_id>/course/<int:course_id>/delete', methods=['POST'])
# def delete_course_post(student_id, course_id):
#     chosen_course = ChosenCourse.query.filter_by(course_id=course_id, student_id=student_id).first_or_404()
#     db.session.delete(chosen_course)
#     db.session.commit()
#     flash('Course deleted successfully!', 'success')
#     return redirect(url_for('student_courses', student_id=student_id))


# if __name__ == '__main__':
#     app.run(debug=True)

